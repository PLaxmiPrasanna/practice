package com.cg.utility;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.Exception.QuoteException;

import oracle.jdbc.OracleDriver;
public class DbConnection
{
public static Connection connection=null;

public static Connection getConnection() throws QuoteException 
{
	Driver driver=new OracleDriver();
	try {
		DriverManager.registerDriver(driver);
		connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
	} catch (SQLException e)
	{
		throw new QuoteException("DB error occurred");
	}
	return connection;
}
}

