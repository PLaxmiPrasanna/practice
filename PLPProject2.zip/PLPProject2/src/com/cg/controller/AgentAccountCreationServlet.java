package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.Exception.QuoteException;
import com.cg.dao.AgentAccountCreationDAO;
import com.cg.dao.IAgentAccountCreation;
import com.cg.model.Accounts;
import com.oracle.jrockit.jfr.RequestDelegate;

import sun.rmi.server.Dispatcher;

@WebServlet("/AgentAccountCreationServlet")
public class AgentAccountCreationServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String userName = request.getParameter("userName");
		String insuredName = request.getParameter("insuredName");
		String insuredStreet = request.getParameter("insuredStreet");
		String insuredCity = request.getParameter("insuredCity");
		String insuredState = request.getParameter("insuredState");
		Integer insuredZip = Integer.parseInt(request.getParameter("insuredZip"));
		String busSegName = request.getParameter("busSegName");
		Integer accNumber = Integer.parseInt(request.getParameter("accNumber"));

		IAgentAccountCreation iAgentAccountCreation = new AgentAccountCreationDAO();
		Accounts account = new Accounts(userName, insuredName, insuredStreet, insuredCity, insuredState, insuredZip,
				busSegName, accNumber);

		try {// if user exists is userrole table...
			String rolecode = iAgentAccountCreation.isUserExist(userName);
			out.println("in servlet:" + rolecode);
			if (rolecode.equals("")) {
				out.println("User does not exists");
				request.getRequestDispatcher("AgentHomePage.html").forward(request, response);
			}
			// if user exists in account table or not(to check whether he has account
			// previously or not)....
			else {
				String username = iAgentAccountCreation.isAccountExists(userName);

				if (username.equals("")) {
					int rowsInserted = iAgentAccountCreation.createAccount(account);
					if (rowsInserted > 0) {
						out.println("Account successfully created");
						request.getRequestDispatcher("AgentHomePage.html").forward(request, response);
					}
				} else {
					out.println("Account already exists");
					request.getRequestDispatcher("AgentHomePage.html").forward(request, response);
				}
			}
		} catch (QuoteException e) {
			System.out.println("error in servlet while inserting rows:" + e);
		}

	}
}
