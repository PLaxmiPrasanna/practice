package com.cg.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.Exception.QuoteException;
import com.cg.dao.AgentPolicyCreationDAO;
import com.cg.dao.IAgentPolicyCreationDAO;
import com.cg.model.PolicyQuestions;

@WebServlet("/AgentPolicyCreation")
public class AgentPolicyCreationServlet extends HttpServlet 
{
 @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
 {
	int accNo=Integer.parseInt(request.getParameter("accNo"));
	IAgentPolicyCreationDAO iAgentPolicyCreation =new AgentPolicyCreationDAO();
	List<PolicyQuestions> quesList =new ArrayList<>();
	try
	{
		String bus_seg_id=iAgentPolicyCreation.isAccountExists(accNo);
		if(bus_seg_id.equals(""))
		{
			request.setAttribute("accountNotFound", "account doesnt exist for this account number");
			request.getRequestDispatcher("AgentHomePage.html").include(request, response);
		}
		//System.out.println(bus_seg_id);
		quesList=iAgentPolicyCreation.findQuestions(bus_seg_id);
		request.setAttribute("Questions",quesList);
		request.getRequestDispatcher("AgentPolicyCreation.jsp").include(request, response);
	} 
	catch (QuoteException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
