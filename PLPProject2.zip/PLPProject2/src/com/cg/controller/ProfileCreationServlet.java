package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.Exception.QuoteException;
import com.cg.dao.IUserRoleDAO;
import com.cg.dao.UserRoleDAO;
import com.cg.model.UserRole;
import com.cg.utility.DbConnection;

@WebServlet("/ProfileCreation")
public class ProfileCreationServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		IUserRoleDAO userRoleDAO = new UserRoleDAO();
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String roleCode = request.getParameter("rolecode");
		System.out.println(userName + " " + password + " " + roleCode);
		UserRole userRole = new UserRole(userName, password, roleCode);
		try {

			int rowsInserted = userRoleDAO.addUser(userRole);
			if (rowsInserted > 0) {
				out.println("Successfully inserted");
				dispatcher = request.getRequestDispatcher("AdminHomePage.html");

				dispatcher.include(request, response);
			} else {
				out.println("Username already exists!!");
				dispatcher = request.getRequestDispatcher("AdminProfileCreation.html");
				dispatcher.include(request, response);
			}
		} catch (QuoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
