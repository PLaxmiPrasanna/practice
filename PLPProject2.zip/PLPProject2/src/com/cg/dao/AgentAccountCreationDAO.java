package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;


import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;
import com.cg.utility.DbConnection;

public class AgentAccountCreationDAO implements IAgentAccountCreation
{

	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultset=null;
	@Override
	public String isUserExist(String userName) throws QuoteException 
	{
		String rolecode="";
		try {
			connection=DbConnection.getConnection();
			statement=connection.prepareStatement(QueryConstants.AGENT_VERIFY_USER);
			statement.setString(1, userName);
			resultset=statement.executeQuery();
			while(resultset.next())
			{
				rolecode=resultset.getString(1);
			}
			
		} catch (QuoteException | SQLException e) {
			System.out.println("error in DAO while verifying user: "+e);
		}
		finally {
			try
			{
				statement.close();
				connection.close();
			}
			catch (Exception e) 
			{
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
		}
		
		return rolecode;
		
	}
	@Override
	public String isAccountExists(String userName) throws QuoteException
	{
		String username="";
		try {
			connection=DbConnection.getConnection();
			statement=connection.prepareStatement(QueryConstants.USER_EXISTS_IN_ACCOUNT);
			statement.setString(1, userName);
			resultset=statement.executeQuery();
			while(resultset.next())
			{
				username=resultset.getString(1);
			}
		} catch (QuoteException | SQLException e) {
			System.out.println("error in DAO WHILE VERIFYING ACCOUUNT: "+e);
		}
		finally {
			try
			{
				connection.close();
				statement.close();
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return username;
		
	}
	@Override
	public int createAccount(Accounts account) throws QuoteException 
	{
		int rowsInserted=0;
		PreparedStatement statement1 = null;
		try {
			connection=DbConnection.getConnection();
			
			statement1=connection.prepareStatement(QueryConstants.ACCOUNT_CREATION);
			statement1.setInt(1,account.getAccountNumber());
			statement1.setString(2, account.getInsuredName());
			statement1.setString(3, account.getInsuredStreet());
			statement1.setString(4, account.getInsuredCity());
			statement1.setString(5, account.getInsuredState());
			statement1.setInt(6, account.getInsuredZip());
			statement1.setString(7, findBusSegId(account.getLineOfBusiness()));
			System.out.println(account.getLineOfBusiness());
			System.out.println(findBusSegId(account.getLineOfBusiness()));
			statement1.setString(8, account.getUserName());
			rowsInserted=statement1.executeUpdate();
			
		} catch (QuoteException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//			System.out.println("error in DAO while inserting rows: "+e);
		}
		finally
		{
			try
			{
			connection.close();
			statement1.close();
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		
		return rowsInserted;
	}
	private String findBusSegId(String lineOfBusiness) throws QuoteException
	{
		String busSegId="";
		try {
			connection=DbConnection.getConnection();
			statement=connection.prepareStatement(QueryConstants.GET_LOB_NAME);
			statement.setString(1, lineOfBusiness);
			resultset=statement.executeQuery();
			while(resultset.next())
			{
				 busSegId = resultset.getString(1);
			}
		} catch (SQLException |QuoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try
			{
			connection.close();
			statement.close();
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		return busSegId;
		
	}
	
	

}
