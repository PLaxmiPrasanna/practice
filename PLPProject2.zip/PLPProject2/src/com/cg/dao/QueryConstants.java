package com.cg.dao;

public interface QueryConstants {

	String VERIFY_USER = "SELECT * FROM USERROLE WHERE username=? and password=?";
	
	String INSERT_USER = "insert into userRole values(?,?,?)";

	String GET_ROLECODE = "select rolecode from userrole where username = ? and password = ?";
	
	String ACCOUNT_CREATION = "insert into accounts values(?,?,?,?,?,?,?,?)";
	
	String GET_LOB_NAME = "select bus_seg_id from businesssegment where bus_seg_name = ?";
	
	String USER_EXISTS = "select * from userrole where username = ?";
	
	String USER_EXISTS_IN_ACCOUNT = "select username from accounts where username = ?";
	
	
	//Agent.....
	 String AGENT_VERIFY_USER="SELECT ROLECODE FROM USERROLE WHERE USERNAME=?";
	 
	 String AGENT_VERIFY_ACCOUNT="SELECT BUSINESSSEGMENTID FROM ACCOUNTS WHERE ACCOUNTNUMBER=?";
	 
	 String AGENT_POLICY_QUESTIONS="SELECT * FROM POLICYQUESTIONS WHERE BUSINESSSEGMENTID=?";
	
}
