package com.cg.dao;

import java.sql.ResultSet;

import com.cg.Exception.QuoteException;

public interface IAgentPolicyCreationDAO
{
 public String isAccountExists(int accNumber) throws QuoteException;
 public ResultSet findQuestions(String bus_seg_id) throws QuoteException;
}
