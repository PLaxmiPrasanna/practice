package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;
import com.cg.utility.DbConnection;

public class AccountsDAO implements IAccountsDAO{

	static Connection connection=null;
	static PreparedStatement statement=null;
	static ResultSet resultset=null;
	
	@Override
	public int accountCreation(Accounts account,String userName) throws QuoteException {
		// TODO Auto-generated method stub

		connection = DbConnection.getConnection();
		int isInserted = 0;
		try {
			statement = connection.prepareStatement(QueryConstants.ACCOUNT_CREATION);
			statement.setInt(1, account.getAccountNumber());
			statement.setString(2, account.getInsuredName());
			statement.setString(3, account.getInsuredStreet());
			statement.setString(4, account.getInsuredCity());
			statement.setString(5, account.getInsuredState());
			statement.setInt(6, account.getInsuredZip());
			statement.setString(7, account.getLineOfBusiness());
			statement.setString(8, userName);
			
			isInserted = statement.executeUpdate();
			

		} catch (SQLException e) {
			throw new QuoteException("problem while creating PS object "+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QuoteException("problem while closing");
			}

		}
		
		return isInserted;
	}

}
