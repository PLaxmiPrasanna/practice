package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.Exception.QuoteException;
import com.cg.utility.DbConnection;

public class AgentPolicyCreationDAO implements IAgentPolicyCreationDAO
{
Connection connection=null;
PreparedStatement statement=null;
ResultSet resultset=null;
@Override
public String isAccountExists(int accNumber) throws QuoteException
{
	String bus_seg_id="";
	try 
	{
		connection=DbConnection.getConnection();
		statement=connection.prepareStatement(QueryConstants.AGENT_VERIFY_ACCOUNT);
		statement.setInt(1, accNumber);
		resultset=statement.executeQuery();
		while(resultset.next())
		{
		 bus_seg_id=resultset.getString(1);
		}
	} 
	catch (QuoteException | SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return bus_seg_id;
}
@Override
public ResultSet findQuestions(String bus_seg_id) throws QuoteException
{
	try
	{
		connection = DbConnection.getConnection();
		statement = connection.prepareStatement(QueryConstants.AGENT_POLICY_QUESTIONS);
		statement.setString(1, bus_seg_id);
		resultset=statement.executeQuery();
	} 
	catch (SQLException | QuoteException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 return resultset;
}


}
