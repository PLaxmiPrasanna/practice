import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  colorArr = ["Red", "Blue", "Green", "Yellow"];
  v = 0;
  curr

  // constructor() {
  //   this.changeColor();
  // }
  
  changeColor() {
    this.v = (this.v+1)%this.colorArr.length;
    this.curr = { "background-color": this.colorArr[this.v]};
  }

 
}
