package com.capgemini.labbook.lab11.dao;

import com.capgemini.labbook.lab11.dto.PurchaseDetails;

public interface PurchaseDAO {
	
	
	public void viewMobileDetails() throws Exception;
	
	public void deleteMobile(int id) throws Exception;

	void addCustomer(PurchaseDetails pd) throws Exception;

	public static int getMobileIdMethod(String mobileName) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
