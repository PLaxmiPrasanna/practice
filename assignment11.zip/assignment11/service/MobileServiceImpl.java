package com.capgemini.labbook.lab11.service;

import com.capgemini.labbook.lab11.dao.PurchaseDAOImpl;
import com.capgemini.labbook.lab11.dto.PurchaseDetails;

public class MobileServiceImpl implements MobileService{

	public String addCustomer(PurchaseDetails pd) throws Exception {
		// TODO Auto-generated method stub
		PurchaseDAOImpl dao = new PurchaseDAOImpl();
		dao.addCustomer(pd);
		return "added";
	}
 
	public void viewMobileDetails() throws Exception {
		PurchaseDAOImpl dao = new PurchaseDAOImpl();
		dao.viewMobileDetails();
	}

	@Override
	public void deleteMobile(int id) throws Exception {
		// TODO Auto-generated method stub
		PurchaseDAOImpl dao = new PurchaseDAOImpl();
		dao.deleteMobile(id);
		
	}

	@Override
	public void searchMobile(int price) throws Exception {
		// TODO Auto-generated method stub
		PurchaseDAOImpl dao = new PurchaseDAOImpl();
		dao.searchMobile(price);
		
	}
	
}
