package com.capgemini.labbook.lab11.service;

import com.capgemini.labbook.lab11.dto.PurchaseDetails;

public interface MobileService {
	
	public String addCustomer(PurchaseDetails pd) throws Exception;
	
	public void viewMobileDetails() throws Exception;

	public void deleteMobile(int id) throws Exception;

	public void searchMobile(int price) throws Exception;

}
