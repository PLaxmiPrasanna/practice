package com.capgemini.labbook.lab11.service;

public class MobileValidator {

}
