package com.cg.qgs.dao;

import java.util.List;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy_Questions;
import com.cg.qgs.model.UserRole;

public interface IAdminDAO {

	public boolean loginValidation(String userName, String password) throws QGSException;
	
	public String getRoleCode(String userName, String password) throws QGSException;
	
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QGSException;
	
	public int addUser(UserRole userRole) throws QGSException;

	public int accountCreation(Accounts account, String userName) throws QGSException;

	public boolean isUserExists(String userName) throws QGSException;
	
	public String getBusSegId(int accNumber) throws QGSException;
	
	public List<Policy_Questions> getPolicyQuestions(String busSegId) throws QGSException;
	
	public Integer getPolicyPremiumAmount(Integer sumOfWeightages) throws QGSException;
	
	public Integer createPolicy(Integer polPremium,Integer accNum) throws QGSException;
}
