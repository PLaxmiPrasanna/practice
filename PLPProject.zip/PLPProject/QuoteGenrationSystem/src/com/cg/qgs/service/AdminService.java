package com.cg.qgs.service;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.dao.IAdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;

public class AdminService implements IAdminService {

	IAdminDAO adminDao = new AdminDAO();
	@Override
	public boolean loginValidation(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.loginValidation(username, password);
	}

	@Override
	public String getRoleCode(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getRoleCode(username, password);
	}

	@Override
	public int accountCreation(Accounts account, String userName) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.accountCreation(account,userName);
	}

	


}
