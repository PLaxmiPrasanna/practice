package com.cg.qgs.service;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;

public interface IAdminService {


	public boolean loginValidation(String userName, String password) throws QGSException;
	
	public String getRoleCode(String userName, String password) throws QGSException;

	public int accountCreation(Accounts account, String userName) throws QGSException;

}
