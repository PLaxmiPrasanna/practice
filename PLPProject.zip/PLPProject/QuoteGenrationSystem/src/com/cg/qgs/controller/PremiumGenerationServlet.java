package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.exceptions.QGSException;

import jdk.nashorn.internal.runtime.Context;

@WebServlet("/PremiumGenerationServlet")
public class PremiumGenerationServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int polPremium = 0;
		int sumOfWeightages = 0;
		int isInserted = 0;
		int accNumber = 0;
		RequestDispatcher dispatcher = null;
		for(int i = 1; i < 10; i++) {
			sumOfWeightages += Integer.parseInt(request.getParameter(""+i));
		}
		out.print(sumOfWeightages);
		AdminDAO adminDao = new AdminDAO();
		try {
			ServletContext context = request.getServletContext();
			//context.setAttribute("accNumber", accNumber);
			accNumber = Integer.parseInt(""+context.getAttribute("accNumber"));
			polPremium = adminDao.getPolicyPremiumAmount(sumOfWeightages);
			System.out.println(accNumber);
			isInserted = adminDao.createPolicy(polPremium,accNumber);
			if(isInserted > 0) {
				out.println("Policy created successfully!!!!");
				dispatcher = request.getRequestDispatcher("adminhome.html");
				dispatcher.include(request, response);
			
			}
			/*System.out.println(polPremium);
			out.println(polPremium);
			*/			
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
