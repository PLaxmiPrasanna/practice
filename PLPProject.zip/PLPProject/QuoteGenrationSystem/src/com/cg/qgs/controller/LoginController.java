package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IAdminService service = new AdminService();
		String roleCode = "";
		boolean isFound = false;
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		try {
			isFound = service.loginValidation(username,	password);
			if(isFound == true) {
				roleCode = service.getRoleCode(username, password);
				if(roleCode != null) {
					if(roleCode.equals("UW")) {
						request.getRequestDispatcher("adminhome.html").forward(request, response);
					}
					else if(roleCode.equals("A")) {
						request.getRequestDispatcher("agenthome.html").forward(request, response);
					}
					else if(roleCode.equals("I")){
						request.getRequestDispatcher("insurerhome.html").forward(request, response);
					}
					
				}
				
			}
			else {
				out.println("User not found");
				System.out.println("User not found");
			}

		} catch (QGSException e) {
			System.out.println(e.getMessage());
		}
	}
}
