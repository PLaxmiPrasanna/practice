package com.cg.qgs.dao;

public interface AgentQueryConstants {


	 String AGENT_VERIFY_USER="SELECT ROLECODE FROM USERROLE WHERE USERNAME=?";
	 
	 String USER_EXISTS_IN_ACCOUNT = "select username from accounts where username = ?";
	 
	 String ACCOUNT_CREATION = "insert into accounts values(?,?,?,?,?,?,?,?)";
	 
	 String VALIDATE_ACCOUNT_QUERY ="select * from accounts where username = ?";
	 
	 String GET_LOB_NAME = "select bus_seg_id from businesssegment where bus_seg_name = ?";
		
	 String AGENT_VERIFY_ACCOUNT="SELECT BUSINESSSEGMENTID FROM ACCOUNTS WHERE ACCOUNTNUMBER=?";
	 
	 //String AGENT_POLICY_QUESTIONS="SELECT * FROM POLICYQUESTIONS WHERE BUS_SEG_ID=?";
	 
	 String GET_POLICY_PREMIUM="SELECT PRE_AMT FROM PREMIUMS WHERE ? BETWEEN PRE_ANS_WEIGHTAGE_MIN AND PRE_ANS_WEIGHTAGE_MAX";
	 
	 String INSERT_POLICY="INSERT INTO POLICY VALUES(policyNumberSeq.nextval,?,?)";
	 
	 String INSERT_POLICYDETAILS="INSERT INTO POLICYDETAILS VALUES((SELECT MAX(POLICYNUMBER) FROM POLICY),?,?)";
	 
	 String INSERT_POLICYCREATOR="INSERT INTO POLICYCREATOR VALUES((SELECT MAX(POLICYNUMBER) FROM POLICY),?)";

	String VALIDATE_ACCOUNT = "select * from accounts where accountnumber = ?";

	String GET_BUS_SEG_ID = "select businesssegmentid from accounts where accountnumber = ?";

	String GET_POLICY_QUESTIONS = "select * from policyquestions where bus_seg_id = ?";

	String GET_POLICY_PREMIUM_AMOUNT = "select pre_amt from premiums where ? between pre_ans_weightage_min and pre_ans_weightage_max";

	String CREATE_POLICY = "insert into policy values(policy_number.nextval, ?, ?)";
	 
	String GET_POLICY_NUMBER = "select max(policynumber) from policy";
	
	String ADD_POLICY_DETAILS = "insert into policydetails values(?,?,?)";
	
}
