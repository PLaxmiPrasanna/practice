package com.cg.qgs.controller;

import java.io.IOException;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.dao.InsuredDAO;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		IAdminService service = new AdminService();
		String roleCode = "";
		boolean isFound = false;
		boolean isFound1=false;
		int isCreated = 0;
		boolean isUserExists = false;
		RequestDispatcher dispatcher=null;
		AdminDAO adminDao = new AdminDAO();
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		session.setAttribute("username", username);
		String password = request.getParameter("password");
		Accounts account = new Accounts(username);
		try {
			isFound = service.loginValidation(username,	password);
			System.out.println(isFound);
			if(isFound == true) {
				roleCode = service.getRoleCode(username, password);
			System.out.println(roleCode);
				if(roleCode != null) {
					if(roleCode.equals("UW")) {
						request.getRequestDispatcher("adminhome.html").forward(request, response);
					}
					else if(roleCode.equals("A")) {
						request.getRequestDispatcher("agenthome.html").forward(request, response);
					}
					else if(roleCode.equals("I")){
						isUserExists = adminDao.accountValidation(username);
						if (isUserExists) {
							//if (isCreated == 1) {
								//out.println("Account Created Successfully!!");
								dispatcher = request.getRequestDispatcher("insurerhome.html");
								dispatcher.forward(request, response);
						}else {
									out.println("Account does not exists! Create Account");
									dispatcher = request.getRequestDispatcher("insuredhome1.html");
									dispatcher.include(request, response);
						}
					}else {
							out.println("User does not exists! First register as user");
							dispatcher = request.getRequestDispatcher("adminhome.html");
							dispatcher.include(request, response);
					    }
						
						//request.getRequestDispatcher("insurerhome.html").forward(request, response);
					
					
				}
				
			}
			else {
				out.println("User not found");
				System.out.println("User not found");
			}

		} catch (QGSException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	}

