package com.cg.qgs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.dao.IAdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Policy;
@WebServlet("/InsuredViewPolicy")
public class InsuredViewPolicy extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAdminDAO adminDao = new AdminDAO();
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		try {
			String username = (String)session.getAttribute("username");
			int accNo = adminDao.getAccountNumber(username);
			List<Policy> policies = adminDao.getInsuredPolicies(accNo);
			System.out.println(policies);
			request.setAttribute("policies", policies);
			dispatcher = request.getRequestDispatcher("InsuredViewPolicies.jsp");
			dispatcher.include(request, response);
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

